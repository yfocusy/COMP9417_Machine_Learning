1. Dataset
Please download the ml-latest-small dataset from movieLens
http://files.grouplens.org/datasets/movielens/ml-latest-small.zip

2. Dataset and code folder
Create a folder called "data" and put up-zipped ml-latest-small.zip files inside
Make sure this "data" folder (with data files) is in your current working directory.

3. Import python Modules
pandas
numpy
sklearn 
copy

4. Code Running time
around 230s 

5. Run code
Use Terminal: 
Python3 recommender.py
Note: During the process, you need to input an uid to get the recommended movies from this system. 

